# 📖 COMO SUBIR NO GITHUB - PASSO A PASSO

## 🎯 Objetivo

Colocar seu site online no GitHub Pages em **5 minutos**.

---

## ✅ PASSO 1: CRIAR CONTA NO GITHUB

Se você não tem conta:

1. Acesse: **https://github.com**
2. Clique em **"Sign up"**
3. Preencha email, senha e nome de usuário
4. Confirme seu email

**Se já tem conta, pule para o Passo 2.**

---

## 📁 PASSO 2: CRIAR REPOSITÓRIO

1. Acesse: **https://github.com/new**
2. Preencha:
   - **Repository name**: `tl-fisio-simple`
   - **Description**: Site TL Fisioterapia e Pilates
   - **Public**: ✅ Deixe marcado
3. Clique em **"Create repository"**

**Copie o link que aparece:**
```
https://github.com/seu-usuario/tl-fisio-simple.git
```

---

## 💻 PASSO 3: FAZER UPLOAD DO CÓDIGO

### Opção A: COM TERMINAL (Recomendado)

#### 3A.1 Abra o Terminal

- **Mac/Linux**: Terminal
- **Windows**: PowerShell

#### 3A.2 Navegue até a pasta

```bash
cd caminho/para/tl-fisio-simple
```

#### 3A.3 Configure seu Git (primeira vez apenas)

```bash
git config --global user.name "Seu Nome"
git config --global user.email "seu-email@gmail.com"
```

#### 3A.4 Inicialize o Git

```bash
git init
git add .
git commit -m "Primeiro commit: Site TL Fisioterapia"
```

#### 3A.5 Adicione o repositório remoto

```bash
git remote add origin https://github.com/seu-usuario/tl-fisio-simple.git
git branch -M main
git push -u origin main
```

**Se pedir senha**: Use seu **Personal Access Token** (veja abaixo)

### Como Criar Personal Access Token:

1. Acesse: **https://github.com/settings/tokens**
2. Clique em **"Generate new token"**
3. Preencha:
   - **Note**: `meu-token`
   - **Expiration**: `No expiration`
4. Marque: **✅ repo**
5. Clique em **"Generate token"**
6. **COPIE O TOKEN** (você não verá novamente!)
7. Use como **senha** no terminal

---

### Opção B: SEM TERMINAL

1. Acesse seu repositório: `https://github.com/seu-usuario/tl-fisio-simple`
2. Clique em **"Add file"** → **"Upload files"**
3. Arraste os arquivos (index.html, README.md, .gitignore)
4. Clique em **"Commit changes"**

---

## 🌐 PASSO 4: ATIVAR GITHUB PAGES

1. Acesse seu repositório
2. Clique em **"Settings"** (engrenagem)
3. Clique em **"Pages"** (lado esquerdo)
4. Em **"Source"**, selecione: **main branch**
5. Clique em **"Save"**

**Aguarde 2-3 minutos...**

---

## ✨ PRONTO!

Seu site está online em:

```
https://seu-usuario.github.io/tl-fisio-simple
```

**Compartilhe este link com seus pacientes! 🎉**

---

## 🔄 FAZER MUDANÇAS NO FUTURO

### Com Terminal:

```bash
# Edite o arquivo index.html
# Depois execute:

git add index.html
git commit -m "Atualizar informações"
git push
```

O site será atualizado em 1-2 minutos.

### Sem Terminal:

1. Acesse seu repositório no GitHub
2. Clique no arquivo `index.html`
3. Clique no ícone de lápis (editar)
4. Faça as alterações
5. Clique em **"Commit changes"**

O site será atualizado em 1-2 minutos.

---

## ❓ DÚVIDAS COMUNS

**P: Preciso pagar?**
R: Não! GitHub Pages é completamente grátis.

**P: Quanto tempo leva para ficar online?**
R: 2-3 minutos após fazer o upload.

**P: Posso usar meu próprio domínio?**
R: Sim! Depois, você pode conectar um domínio personalizado nas configurações.

**P: O site fica online sempre?**
R: Sim! 24/7, sem interrupções.

**P: Como faço para deletar o site?**
R: Vá para Settings e clique em "Delete this repository".

---

## 📞 SUPORTE

Se tiver dúvidas:
- Email: tlfisioterapia@gmail.com
- WhatsApp: (65) 99817-1995

---

**Boa sorte! Seu site vai estar online em minutos! 🚀**
