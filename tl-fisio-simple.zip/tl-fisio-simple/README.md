# 🏥 TL Fisioterapia e Pilates - Site de Links

Um site simples, moderno e responsivo para a clínica **TL Fisioterapia e Pilates**.

## ✨ Características

- ✅ **HTML Puro** - Sem dependências complexas
- ✅ **Totalmente Responsivo** - Funciona em qualquer dispositivo
- ✅ **Rápido de Carregar** - Arquivo único e leve
- ✅ **Fácil de Editar** - Código simples e bem organizado
- ✅ **Pronto para GitHub Pages** - Deploy automático

## 🚀 Como Usar

### 1. Clonar o Repositório

```bash
git clone https://github.com/seu-usuario/tl-fisio-simple.git
cd tl-fisio-simple
```

### 2. Abrir Localmente

Simplesmente abra o arquivo `index.html` no seu navegador:
- **Windows/Mac**: Clique duas vezes no arquivo
- **Linux**: `xdg-open index.html` ou `open index.html`

### 3. Fazer Alterações

Edite o arquivo `index.html` com qualquer editor de texto:
- Visual Studio Code
- Notepad++
- Sublime Text
- Ou até o Bloco de Notas

### 4. Fazer Deploy no GitHub Pages

1. Acesse as configurações do repositório
2. Vá para **Settings** → **Pages**
3. Em **Source**, selecione **main branch**
4. Clique em **Save**

Seu site estará online em: `https://seu-usuario.github.io/tl-fisio-simple`

## 📝 Como Editar

### Mudar Número de WhatsApp

Procure por:
```html
<a href="https://wa.me/5565998171995" ...>
```

E substitua `5565998171995` pelo seu número (com código do país e DDD, sem caracteres especiais).

### Mudar Email

Procure por:
```html
<a href="mailto:tlfisioterapia@gmail.com" ...>
```

E substitua `tlfisioterapia@gmail.com` pelo seu email.

### Mudar Redes Sociais

Procure pelos links do Facebook e Instagram e substitua as URLs.

### Mudar Localização e Horários

Procure pela seção `info-section` e edite as informações.

## 🎨 Personalização

### Mudar Cores

No arquivo `index.html`, procure pela seção `<style>` e mude:

```css
--primary: #d4ff00;        /* Verde-limão */
--secondary: #a855b8;      /* Roxo */
--background: #1a0f2e;     /* Roxo escuro */
```

### Mudar Logo

Substitua o emoji `🏥` por outro emoji ou adicione uma imagem:

```html
<div class="logo">🏥</div>
```

## 📱 Estrutura do Arquivo

```
tl-fisio-simple/
├── index.html          # Arquivo principal (HTML + CSS + JS)
├── README.md           # Este arquivo
└── .gitignore          # Arquivos a ignorar no Git
```

## ✅ Checklist Antes de Publicar

- [ ] Número de WhatsApp correto
- [ ] Email correto
- [ ] Links das redes sociais corretos
- [ ] Localização atualizada
- [ ] Horários corretos
- [ ] Testou em mobile
- [ ] Testou em desktop

## 🔄 Atualizar o Site

1. Edite o arquivo `index.html`
2. Salve o arquivo
3. Faça commit e push:

```bash
git add index.html
git commit -m "Atualizar informações"
git push
```

4. O site será atualizado automaticamente em 1-2 minutos

## 🆘 Problemas Comuns

### Site não aparece no GitHub Pages

- Verifique se o repositório é **público**
- Vá para **Settings** → **Pages** e confirme que está configurado
- Aguarde 2-3 minutos para o deploy

### Links não funcionam

- Verifique se a URL está correta
- Certifique-se de que tem `https://` no início
- Para WhatsApp, use apenas números (sem caracteres especiais)

### Site não fica responsivo

- Limpe o cache do navegador (Ctrl+Shift+Del)
- Teste em outro navegador
- Verifique se a meta tag `viewport` está presente

## 📞 Suporte

Para dúvidas ou sugestões:
- Email: tlfisioterapia@gmail.com
- WhatsApp: (65) 99817-1995

## 📄 Licença

MIT

---

**Versão**: 1.0.0  
**Última atualização**: Maio de 2026

Criado com ❤️ para TL Fisioterapia e Pilates
